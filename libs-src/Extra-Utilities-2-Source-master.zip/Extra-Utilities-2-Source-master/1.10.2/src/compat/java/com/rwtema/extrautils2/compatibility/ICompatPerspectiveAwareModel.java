package com.rwtema.extrautils2.compatibility;

import net.minecraftforge.client.model.IPerspectiveAwareModel;

public interface ICompatPerspectiveAwareModel extends IPerspectiveAwareModel {
}
