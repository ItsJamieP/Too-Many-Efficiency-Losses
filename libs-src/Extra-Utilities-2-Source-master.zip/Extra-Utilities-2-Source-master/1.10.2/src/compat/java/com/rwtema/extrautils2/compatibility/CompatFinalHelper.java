package com.rwtema.extrautils2.compatibility;

public class CompatFinalHelper {
	public static final String DEPENDENCIES = "required-after:Forge@[12.16.1.1887,);after:JEI@[3.13.3.380,)";
	public static final String MC_VERSIONS = "";
}
