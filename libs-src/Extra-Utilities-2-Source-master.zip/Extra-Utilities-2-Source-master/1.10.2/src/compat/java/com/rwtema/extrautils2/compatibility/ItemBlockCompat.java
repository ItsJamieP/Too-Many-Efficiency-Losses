package com.rwtema.extrautils2.compatibility;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;

public class ItemBlockCompat extends ItemBlock {
	public ItemBlockCompat(Block block) {
		super(block);
	}
}
