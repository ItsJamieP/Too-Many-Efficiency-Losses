package com.rwtema.extrautils2.gui.backend;

public interface IWidgetClientTick {
	void updateClient();
}
