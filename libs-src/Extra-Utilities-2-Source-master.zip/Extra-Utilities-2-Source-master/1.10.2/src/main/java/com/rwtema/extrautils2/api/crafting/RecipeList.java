package com.rwtema.extrautils2.api.crafting;

public class RecipeList {
}
