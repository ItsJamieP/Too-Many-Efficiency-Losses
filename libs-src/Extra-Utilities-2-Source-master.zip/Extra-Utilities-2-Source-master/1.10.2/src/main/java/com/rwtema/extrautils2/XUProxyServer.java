package com.rwtema.extrautils2;

public class XUProxyServer extends XUProxy {
}
