package com.rwtema.extrautils2.gui.backend;

import java.util.List;

public interface IAdditionalWidgets {
	List<IWidget> getAdditionalWidgets();
}
