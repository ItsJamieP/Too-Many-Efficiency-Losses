package com.rwtema.extrautils2.fairies;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ClientFairies {
	@SubscribeEvent
	public static void tick(TickEvent.ClientTickEvent event) {

	}
}
