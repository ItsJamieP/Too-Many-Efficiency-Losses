package com.rwtema.extrautils2.eventhandlers;

public class FakeHandler {

	public void villagerSpawn() {

	}
}
