package com.rwtema.extrautils2.crafting.jei;

public class IRecipeHandlerJEI {
}
