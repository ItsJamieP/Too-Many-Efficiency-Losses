package com.rwtema.extrautils2.facades;

public class Facade {
}
