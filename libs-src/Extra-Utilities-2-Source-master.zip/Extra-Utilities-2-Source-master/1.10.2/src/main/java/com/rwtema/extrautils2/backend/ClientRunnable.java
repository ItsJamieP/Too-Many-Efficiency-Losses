package com.rwtema.extrautils2.backend;

public interface ClientRunnable extends Runnable {
	@Override
	default void run() {

	}
}
