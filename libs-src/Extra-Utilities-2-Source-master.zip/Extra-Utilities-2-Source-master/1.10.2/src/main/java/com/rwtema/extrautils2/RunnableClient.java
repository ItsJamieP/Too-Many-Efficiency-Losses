package com.rwtema.extrautils2;

public interface RunnableClient extends Runnable {
	@Override
	default void run() {

	}
}
