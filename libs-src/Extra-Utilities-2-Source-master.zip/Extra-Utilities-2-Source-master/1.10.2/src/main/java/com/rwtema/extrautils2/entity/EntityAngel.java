package com.rwtema.extrautils2.entity;

import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.world.World;

public class EntityAngel extends EntityGhast {
	public EntityAngel(World worldIn) {
		super(worldIn);
	}
}
