package com.rwtema.extrautils2.gui.backend;

public abstract class WidgetRawData extends WidgetBase implements IWidgetServerNetwork {
	public WidgetRawData() {
		super(0, 0, 0, 0);
	}
}
