package com.rwtema.extrautils2.power;

public interface IPassivePower {

}
