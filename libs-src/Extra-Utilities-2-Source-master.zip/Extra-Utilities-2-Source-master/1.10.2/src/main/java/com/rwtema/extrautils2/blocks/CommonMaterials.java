package com.rwtema.extrautils2.blocks;

public class CommonMaterials {

	enum Values {
		GLASS,
		STONE,

	}
}
