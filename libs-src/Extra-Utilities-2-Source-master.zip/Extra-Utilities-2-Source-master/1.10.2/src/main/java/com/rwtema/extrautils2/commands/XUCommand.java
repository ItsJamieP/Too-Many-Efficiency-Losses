package com.rwtema.extrautils2.commands;

public class XUCommand {

}
