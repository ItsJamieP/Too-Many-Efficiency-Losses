package com.rwtema.extrautils2.gui.backend;

public interface ITransferPriority {
	int getTransferPriority();
}
