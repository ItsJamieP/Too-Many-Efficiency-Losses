package com.rwtema.extrautils2.eventhandlers;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class SwordStrengthHandler {
	@SideOnly(Side.CLIENT)
	public void run() {

	}
}
