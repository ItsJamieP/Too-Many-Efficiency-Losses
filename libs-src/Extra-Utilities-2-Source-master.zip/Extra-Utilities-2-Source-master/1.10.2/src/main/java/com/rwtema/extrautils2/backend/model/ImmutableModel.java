package com.rwtema.extrautils2.backend.model;

public class ImmutableModel {
}
