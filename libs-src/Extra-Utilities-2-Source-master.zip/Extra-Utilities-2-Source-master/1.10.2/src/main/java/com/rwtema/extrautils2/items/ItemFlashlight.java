package com.rwtema.extrautils2.items;

import com.rwtema.extrautils2.backend.XUItemFlatMetadata;

public class ItemFlashlight extends XUItemFlatMetadata {

	public ItemFlashlight() {
		super("");
	}

}
