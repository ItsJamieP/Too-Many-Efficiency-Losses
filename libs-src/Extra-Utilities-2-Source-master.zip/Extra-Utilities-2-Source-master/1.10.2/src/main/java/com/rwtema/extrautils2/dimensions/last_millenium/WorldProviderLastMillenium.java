package com.rwtema.extrautils2.dimensions.last_millenium;

import com.rwtema.extrautils2.dimensions.DimensionEntry;
import com.rwtema.extrautils2.dimensions.XUWorldProvider;

public class WorldProviderLastMillenium extends XUWorldProvider {
	public WorldProviderLastMillenium(DimensionEntry entry) {
		super(entry);
	}
}
