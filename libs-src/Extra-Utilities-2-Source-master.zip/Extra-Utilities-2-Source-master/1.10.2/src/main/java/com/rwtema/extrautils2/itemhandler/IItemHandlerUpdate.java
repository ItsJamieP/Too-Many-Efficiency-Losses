package com.rwtema.extrautils2.itemhandler;

public interface IItemHandlerUpdate {
	void onChange(int index);
}
