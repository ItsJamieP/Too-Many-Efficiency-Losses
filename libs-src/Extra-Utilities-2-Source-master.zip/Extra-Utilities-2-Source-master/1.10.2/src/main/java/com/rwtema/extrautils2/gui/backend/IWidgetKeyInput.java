package com.rwtema.extrautils2.gui.backend;

public interface IWidgetKeyInput extends IWidget {
	boolean keyTyped(char key, int keyCode);
}
