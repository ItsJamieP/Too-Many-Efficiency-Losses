package com.rwtema.extrautils2.asm;

public @interface ModAdv {

}
