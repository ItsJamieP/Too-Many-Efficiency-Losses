package com.rwtema.extrautils2.backend;

public interface IServerUpdate {

}
