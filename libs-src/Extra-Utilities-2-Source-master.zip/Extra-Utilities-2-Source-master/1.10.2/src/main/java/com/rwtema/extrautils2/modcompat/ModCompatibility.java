package com.rwtema.extrautils2.modcompat;

public @interface ModCompatibility {
	String mod();
}
