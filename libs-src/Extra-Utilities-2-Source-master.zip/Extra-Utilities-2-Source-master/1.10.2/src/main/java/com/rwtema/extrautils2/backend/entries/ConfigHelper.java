package com.rwtema.extrautils2.backend.entries;

public class ConfigHelper {
	public static final String GAMEPLAY_CATEGORY = "gameplay";
	public static final String ENERGY_CATEGORY = "energy";
}
