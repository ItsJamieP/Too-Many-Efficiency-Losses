package com.rwtema.extrautils2.compatibility;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;

public class TextureAtlasSpriteCompat extends TextureAtlasSprite {
	protected TextureAtlasSpriteCompat(String spriteName) {
		super(spriteName);
	}
}
