package com.rwtema.extrautils2.compatibility;

import net.minecraft.world.WorldSavedData;

public abstract class WorldSavedDataCompat extends WorldSavedData {
	public WorldSavedDataCompat(String name) {
		super(name);
	}
}
