package com.rwtema.extrautils2.compatibility;

import net.minecraft.world.WorldProvider;

public abstract class WorldProviderCompat extends WorldProvider {


}
